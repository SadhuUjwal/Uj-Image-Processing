﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImageRegistrationBySURF
{
    class Transformation
    {
        public double A { get; set; }
        public double B { get; set; }
        public double T1 { get; set; }
        public double T2 { get; set; }
    }
}
